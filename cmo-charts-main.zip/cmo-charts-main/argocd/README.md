# Argo CD

* [Описание](#описание)
* [Values](#values)
* [Развертывание](#развертывание)

## Описание
Argo CD используется для автоматизации развертывания и обновления приложений.

## Values
При развертывании необходимо поменять следующие переменные:
1. global.domain
1. global.image.repository
1. global.image.tag
1. global.imagePullSecrets
1. externalRedis.host (при развертывании redis не в k8s или не нашими чартами)
1. server.ingress.ingressClassName

## Развертывание
1. Заполнить значения в values.
1. helm upgrade --install argocd -f argocd/values.yaml -n argocd

# Чарты CM Ocean (редакция MM One)

* [Описание](#описание)
* [Пререквизиты](#пререквизиты)
* [Развертывание](#развертывание)
* [Поддержка](#поддержка)

## Описание
туду

## Пререквизиты
* Кластер k8s.
* Ingress контроллер должен поддерживать X-Forwarded хэдеры.
* RWM pvc class.
* Рабочая станция с доступом к k8s api с установленными утилитами kubectl и helm.

## Развертывание
Выполнить развертывание необходимых модулей в следующем порядке:
1. [Env Configuration](env-configuration/README.md) (Обязательный модуль)
1. [Redis](redis/README.md) (Обязательный модуль)
1. [Argo CD](argocd/README.md) (Обязательный модуль)
1. Infra
    1. [Keycloak](infra/keycloak/README.md)
    1. [Kafka](infra/kafka/README.md)
    1. [Keycloak Management App](infra/kc-management/README.md) (Обязательный модуль)
1. CM Ocean
    1. [Airflow](cmocean/airflow/README.md)
    1. [Axiom](cmocean/axiom/README.md)

## Поддержка
@Podkinpd


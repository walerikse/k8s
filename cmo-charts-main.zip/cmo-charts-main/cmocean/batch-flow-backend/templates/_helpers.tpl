{{- define "batchflow.postgresql.fullname" -}}
{{- include "common.names.dependency.fullname" (dict "chartName" "postgresql" "chartValues" .Values.postgresql "context" $) -}}
{{- end -}}

{{- define "batchflow.database.host" -}}
{{- ternary (include "batchflow.postgresql.fullname" .) .Values.externalDatabase.host .Values.postgresql.enabled -}}
{{- end -}}

{{- define "batchflow.database.user" -}}
{{- if .Values.postgresql.enabled }}
    {{- if .Values.global.postgresql }}
        {{- if .Values.global.postgresql.auth }}
            {{- coalesce .Values.global.postgresql.auth.username .Values.postgresql.auth.username -}}
        {{- else -}}
            {{- .Values.postgresql.auth.username -}}
        {{- end -}}
    {{- else -}}
        {{- .Values.postgresql.auth.username -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.user -}}
{{- end -}}
{{- end -}}

{{- define "batchflow.database.name" -}}
{{- if .Values.postgresql.enabled }}
    {{- if .Values.global.postgresql }}
        {{- if .Values.global.postgresql.auth }}
            {{- coalesce .Values.global.postgresql.auth.database .Values.postgresql.auth.database -}}
        {{- else -}}
            {{- .Values.postgresql.auth.database -}}
        {{- end -}}
    {{- else -}}
        {{- .Values.postgresql.auth.database -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.database -}}
{{- end -}}
{{- end -}}

{{- define "batchflow.database.secretName" -}}
{{- if .Values.postgresql.enabled }}
    {{- if .Values.global.postgresql }}
        {{- if .Values.global.postgresql.auth }}
            {{- if .Values.global.postgresql.auth.existingSecret }}
                {{- tpl .Values.global.postgresql.auth.existingSecret $ -}}
            {{- else -}}
                {{- default (include "batchflow.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
            {{- end -}}
        {{- else -}}
            {{- default (include "batchflow.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
        {{- end -}}
    {{- else -}}
        {{- default (include "batchflow.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
    {{- end -}}
{{- else -}}
    {{- default (printf "%s-externaldb" (include "common.names.fullname" .)) (tpl .Values.externalDatabase.existingSecret $) -}}
{{- end -}}
{{- end -}}

{{- define "batchflow.service.secretName" -}}
{{- $uniformService := default .Values.uniformService .Values -}}
{{- if $uniformService.existingSecret -}}
    {{- tpl $uniformService.existingSecret $ -}}
{{- else -}}
    {{- printf "%s-service" (include "common.names.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "batchflow.database.secretKey" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{- define "batchflow.database.port" -}}
{{- ternary "5432" .Values.externalDatabase.port .Values.postgresql.enabled -}}
{{- end -}}

{{- define "batchflow.database.existingsecret.key" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{- define "batchflow.executionUrl" -}}
  {{- printf "https://%s.%s%s/engine" .Values.ingress.host .Values.ingress.baseDomain .Values.ingress.uriPrefix -}}
{{- end -}}

{{- define "batchflow.selfUrl" -}}
  {{- printf "https://%s.%s%s" .Values.ingress.host .Values.ingress.baseDomain .Values.ingress.uriPrefix -}}
{{- end -}}

{{- define "batchflow.serviceAccountName" -}}
{{- if .Values.serviceAccount.name }}
    {{- tpl .Values.serviceAccount.name $ -}}
{{- else -}}
    {{- ternary (include "common.names.fullname" .) "default" .Values.serviceAccount.create -}}
{{- end -}}
{{- end -}}

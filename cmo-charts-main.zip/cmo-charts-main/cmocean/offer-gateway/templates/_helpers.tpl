{{/*
Fully qualified app name is truncated at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "offer-gateway.postgresql.fullname" -}}
{{- include "common.names.dependency.fullname" (dict "chartName" "postgresql" "chartValues" .Values.postgresql "context" $) -}}
{{- end -}}

{{/*
Database host
*/}}
{{- define "offer-gateway.database.host" -}}
{{- ternary (include "offer-gateway.postgresql.fullname" .) .Values.externalDatabase.host .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database port
*/}}
{{- define "offer-gateway.database.port" -}}
{{- ternary "5432" .Values.externalDatabase.port .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database name
*/}}
{{- define "offer-gateway.database.name" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- coalesce .Values.postgresql.global.postgresql.auth.database .Values.postgresql.auth.database -}}
        {{- else -}}
            {{- .Values.postgresql.auth.database -}}
        {{- end -}}
    {{- else -}}
        {{- .Values.postgresql.auth.database -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.database -}}
{{- end -}}
{{- end -}}

{{/*
Database schema
*/}}
{{- define "offer-gateway.database.schema" -}}
{{- ternary "public" .Values.externalDatabase.schema .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database user
*/}}
{{- define "offer-gateway.database.user" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- default (printf "%s" "postgres") (coalesce .Values.postgresql.global.postgresql.auth.username .Values.postgresql.auth.username) -}}
        {{- else -}}
            {{- default (printf "%s" "postgres") (tpl .Values.postgresql.auth.username) -}}
        {{- end -}}
    {{- else -}}
        {{- default (printf "%s" "postgres") (tpl .Values.postgresql.auth.username) -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.user -}}
{{- end -}}
{{- end -}}

{{/*
Database password secret name
*/}}
{{- define "offer-gateway.database.secretName" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- if .Values.postgresql.global.postgresql.auth.existingSecret -}}
                {{- tpl .Values.postgresql.global.postgresql.auth.existingSecret $ -}}
            {{- else -}}
                {{- default (include "offer-gateway.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
            {{- end -}}
        {{- else -}}
            {{- default (include "offer-gateway.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
        {{- end -}}
    {{- else -}}
        {{- default (include "offer-gateway.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
    {{- end -}}
{{- else -}}
    {{- default (printf "%s-externaldb" .Release.Name) (tpl .Values.externalDatabase.existingSecret $) -}}
{{- end -}}
{{- end -}}

{{/*
Database password secret key
*/}}
{{- define "offer-gateway.database.secretKey" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Database password existing secret key
*/}}
{{- define "offer-gateway.database.existingsecret.key" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/* Validate values of offer-gateway - database */}}
{{- define "offer-gateway.validateValues.database" -}}
{{- if and (not .Values.postgresql.enabled) (not .Values.externalDatabase.host) (and (not .Values.externalDatabase.password) (not .Values.externalDatabase.existingSecret)) -}}
offer-gateway: database
    You disabled the PostgreSQL sub-chart but did not specify an external PostgreSQL host.
    Either deploy the PostgreSQL sub-chart (--set postgresql.enabled=true),
    or set a value for the external database host (--set externalDatabase.host=FOO)
    and set a value for the external database password (--set externalDatabase.password=BAR)
    or existing secret (--set externalDatabase.existingSecret=BAR).
{{- end -}}
{{- end -}}

{{/* Environment */}}
{{- define "offer-gateway.env" -}}
{{- .Values.service.env -}}
{{- end -}}
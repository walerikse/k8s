{{/*
Fully qualified app name is truncated at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "communication.postgresql.fullname" -}}
{{- include "common.names.dependency.fullname" (dict "chartName" "postgresql" "chartValues" .Values.postgresql "context" $) -}}
{{- end -}}

{{/*
Database host
*/}}
{{- define "communication.database.host" -}}
{{- ternary (include "communication.postgresql.fullname" .) .Values.externalDatabase.host .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database port
*/}}
{{- define "communication.database.port" -}}
{{- ternary "5432" .Values.externalDatabase.port .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database name
*/}}
{{- define "communication.database.name" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- coalesce .Values.postgresql.global.postgresql.auth.database .Values.postgresql.auth.database -}}
        {{- else -}}
            {{- .Values.postgresql.auth.database -}}
        {{- end -}}
    {{- else -}}
        {{- .Values.postgresql.auth.database -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.database -}}
{{- end -}}
{{- end -}}

{{/*
Database schema
*/}}
{{- define "communication.database.schema" -}}
{{- ternary "public" .Values.externalDatabase.schema .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database user
*/}}
{{- define "communication.database.user" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- default (printf "%s" "postgres") (coalesce .Values.postgresql.global.postgresql.auth.username .Values.postgresql.auth.username) -}}
        {{- else -}}
            {{- default (printf "%s" "postgres") (tpl .Values.postgresql.auth.username) -}}
        {{- end -}}
    {{- else -}}
        {{- default (printf "%s" "postgres") (tpl .Values.postgresql.auth.username) -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.user -}}
{{- end -}}
{{- end -}}

{{/*
Database password secret name
*/}}
{{- define "communication.database.secretName" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- if .Values.postgresql.global.postgresql.auth.existingSecret -}}
                {{- tpl .Values.postgresql.global.postgresql.auth.existingSecret $ -}}
            {{- else -}}
                {{- default (include "communication.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
            {{- end -}}
        {{- else -}}
            {{- default (include "communication.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
        {{- end -}}
    {{- else -}}
        {{- default (include "communication.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
    {{- end -}}
{{- else -}}
    {{- default (printf "%s-externaldb" .Release.Name) (tpl .Values.externalDatabase.existingSecret $) -}}
{{- end -}}
{{- end -}}

{{/*
Database password secret key
*/}}
{{- define "communication.database.secretKey" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Database password existing secret key
*/}}
{{- define "communication.database.existingsecret.key" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/* Validate values of communication - database */}}
{{- define "communication.validateValues.database" -}}
{{- if and (not .Values.postgresql.enabled) (not .Values.externalDatabase.host) (and (not .Values.externalDatabase.password) (not .Values.externalDatabase.existingSecret)) -}}
communication: database
    You disabled the PostgreSQL sub-chart but did not specify an external PostgreSQL host.
    Either deploy the PostgreSQL sub-chart (--set postgresql.enabled=true),
    or set a value for the external database host (--set externalDatabase.host=FOO)
    and set a value for the external database password (--set externalDatabase.password=BAR)
    or existing secret (--set externalDatabase.existingSecret=BAR).
{{- end -}}
{{- end -}}

{{/* Kafka security protocol */}}
{{- define "communication.kafka.security.protocol" -}}
{{- if and (.Values.configuration.communication.kafka.properties.sasl.enabled) (.Values.configuration.communication.kafka.properties.ssl.enabled) -}}
    {{- printf "%s" "SASL_SSL" -}}
{{- else if .Values.configuration.communication.kafka.properties.sasl.enabled -}}
    {{- printf "%s" "SASL_PLAINTEXT" -}}
{{- else if .Values.configuration.communication.kafka.properties.ssl.enabled -}}
    {{- printf "%s" "SSL" -}}
{{- else -}}
    {{- printf "%s" "PLAINTEXT" -}}
{{- end -}}
{{- end -}}

{{/* Environment */}}
{{- define "communication.env" -}}
{{- .Values.service.env -}}
{{- end -}}

{{/* Ingress URI Prefix */}}
{{- define "communication.ingress.uriPrefix" -}}
{{- .Values.service.ingress.uriPrefix -}}
{{- end -}}

{{/*
JVM customisation
*/}}
{{- define "jvm.javaToolOptions" -}}
{{- if .Values.jvm.memory.useContainerSupport -}}-XX:+UseContainerSupport -XX:InitialRAMPercentage={{ .Values.jvm.memory.initialRamPercentage }} -XX:MaxRAMPercentage={{ .Values.jvm.memory.maxRamPercentage }}{{- end -}}
{{- if .Values.jvm.args }} {{ .Values.jvm.args }}{{ end }}
{{- if eq .Values.jvm.gc "serial" }} -XX:+UseSerialGC
{{- else if eq .Values.jvm.gc "parallel" }} -XX:+UseParallelGC
{{- else if eq .Values.jvm.gc "g1" }} -XX:+UseG1GC
{{- else if eq .Values.jvm.gc "zgc" }} -XX:+UseZGC{{ end }}
{{- end -}}
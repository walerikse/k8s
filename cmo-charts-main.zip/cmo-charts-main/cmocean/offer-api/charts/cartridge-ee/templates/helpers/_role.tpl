{{- define "role.ports.http" }}
  {{- $ := .context }}
  {{- $role := .role }}
  {{- if $role.ports }}
    {{- if $role.ports.http }}
      {{- $role.ports.http -}}
    {{- else }}
      {{- $.Values.tarantool.ports.http -}}
    {{- end }}
  {{- else -}}
    {{- $.Values.tarantool.ports.http -}}
  {{- end -}}
{{- end -}}

{{- define "role.ports.tarantool" }}
  {{- $ := .context }}
  {{- $role := .role }}
  {{- if $role.ports }}
    {{- if $role.ports.tarantool }}
      {{- $role.ports.tarantool -}}
    {{- else }}
      {{- $.Values.tarantool.ports.tarantool -}}
    {{- end }}
  {{- else -}}
    {{- $.Values.tarantool.ports.tarantool -}}
  {{- end -}}
{{- end }}

{{- define "role.default.service" }}
{{- $httpPort := (include "role.ports.http" (dict "role" .role "context" .context)) -}}
{{- $tarantoolPort := (include "role.ports.tarantool" (dict "role" .role "context" .context)) -}}
type: ClusterIP
ports:
  http: {{ $httpPort }}
  tarantool: {{ $tarantoolPort }}
nodePorts:
  metrics: ""
clusterIP: ""
loadBalancerIP: ""
loadBalancerSourceRanges: []
externalTrafficPolicy: Cluster
annotations: {}
sessionAffinity: None
sessionAffinityConfig: {}
{{- end -}}

{{- define "role.default.autoscaling" }}
replicas:
  enabled: false
  annotations: {}
  minReplicas: 2
  maxReplicas: 4
  behavior:
    checkIntervalSeconds: 30
    scaleUp:
      stabilizationWindowSeconds: 0
    scaleDown:
      stabilizationWindowSeconds: 150
  metrics: []
replicasets:
  enabled: false
  annotations: {}
  minReplicasets: 1
  maxReplicasets: 4
  behavior:
    checkIntervalSeconds: 30
    scaleUp:
      stabilizationWindowSeconds: 0
    scaleDown:
      stabilizationWindowSeconds: 150
  metrics: []
{{- end }}
{{- define "validation.bucketCount" -}}
    {{- if le .Values.tarantool.bucketCount 0.0 -}}
        {{- fail ".Values.bucketCount shoud be greater then 0" -}}
    {{- end -}}
{{- end -}}

{{- define "validation.failover.timeout" -}}
    {{- if le .Values.failover.timeout 0.0 -}}
        {{- fail ".Values.failover.timeout shoud be greater then 0" -}}
    {{- end -}}
{{- end -}}

{{- define "validation.failover.etcd2.lockDelay" -}}
    {{- if eq .Values.failover.mode "stateful" -}}
        {{- if le .Values.failover.etcd2.lockDelay 0.0 -}}
            {{- fail ".Values.failover.etcd2.lockDelay shoud be greater then 0" -}}
        {{- end -}}

        {{- if le .Values.failover.etcd2.lockDelay .Values.failover.timeout -}}
            {{- fail (printf ".Values.failover.etcd2.lockDelay shoud be greater then .Values.failover.timeout (greater then %f)" .Values.failover.timeout) -}}
        {{- end -}}
    {{- end -}}
{{- end -}}

{{- define "validation.raft" }}
    {{- $ := .context }}
    {{- $role := .role }}
    {{- if eq $.Values.failover.mode "raft" -}}
        {{- if not $role.allRw -}}
            {{- if lt ($role.replicas | int) (3 | int) -}}
                {{- fail (printf "RAFT failover cannot be enabled if any non-allRW role has less than 3 replicas. Please increase replicas for role `%s`" $role.name) -}}
            {{- end -}}
        {{- end -}}
    {{- end -}}
{{- end }}

{{- define "validation.scaledown" }}
    {{- $ := .context }}
    {{- $role := .role }}
    {{- if not (or (eq $.Values.failover.mode "stateful") (eq $.Values.failover.mode "raft")) -}}
        {{- $oldRole := lookup "tarantool.io/v1alpha1" "Role" $.Release.Namespace $role.name -}}
        {{- if $oldRole -}}
            {{- if lt ($role.replicas | int) ($oldRole.spec.replicasetTemplate.replicas | int) -}}
                {{- fail (printf "Unable to decrease replicas for role %s. RAFT of stateful failover must be enabled for scaling down" $role.name) -}}
            {{- end -}}
        {{- end -}}
    {{- end -}}
{{- end }}

{{- define "validation.rollingUpdate" }}
    {{- $ := .context }}
    {{- $role := .role }}
    {{- if $role.updateStrategy -}}
        {{- if eq $role.updateStrategy.type "ClusterPartitionUpdate" -}}
            {{- $instancesCount := (mul ($role.replicasets | int) ($role.replicas | int)) -}}
            {{- if lt $instancesCount (2 | int) -}}
                {{- fail (printf "Update strategy ClusterPartitionUpdate reqires at least 2 replicas in role. Please increase replicasets or replicas for role `%s`" $role.name) -}}
            {{- end -}}

            {{- if ge ($role.updateStrategy.clusterPartitionUpdate.maxUnavailable | int) $instancesCount -}}
                {{- fail (printf "Value of updateStrategy.clusterPartitionUpdate.maxUnavailable for role %s must be less then total count of instances (replicasets * replicas) in role." $role.name) -}}
            {{- end -}}
        {{- end -}}

        {{- if eq $role.updateStrategy.type "SwitchMasterUpdate" -}}
            {{- if not (or (eq $.Values.failover.mode "stateful") (eq $.Values.failover.mode "raft")) -}}
                {{- fail (printf "Update strategy SwitchMasterUpdate is enabled for role %s its require to enable stateful or raft failover" $role.name) -}}
            {{- end }}

            {{- if lt ($role.replicas | int) (2 | int) -}}
                {{- fail (printf "Update strategy SwitchMasterUpdate reqires at least 2 replicas in role. Please increase replicas for role `%s`" $role.name) -}}
            {{- end -}}

            {{- if ge ($role.updateStrategy.switchMasterUpdate.maxUnavailableReplicas | int) ($role.replicas | int) -}}
                {{- fail (printf "Value of updateStrategy.switchMasterUpdate.maxUnavailableReplicas for role %s must be less then replicas." $role.name) -}}
            {{- end -}}
        {{- end -}}
    {{- end -}}
{{- end }}

{{- define "validation.memtxMemory" }}
    {{- $ := .context }}
    {{- $role := .role }}
    {{- $memtxMemory := $role.memtxMemory | default $.Values.tarantool.memtxMemory }}
    {{- if $memtxMemory -}}
        {{- $memtxMemoryBytes := ((include "tarantool.memory_quantity_to_bytes" $memtxMemory) | int64) -}}
        {{- if le $memtxMemoryBytes 0 }}
            {{- fail (printf "%s.memtxMemory must be greater than 0" $role.name) -}}
        {{- end -}}
        {{- $resources := $role.resources | default $.Values.tarantool.resources }}
        {{- if $resources -}}
            {{- if $resources.limits -}}
                {{- if $resources.limits.memory -}}
                    {{- $memoryLimit := ((include "tarantool.memory_quantity_to_bytes" $resources.limits.memory) | int64) -}}
                    {{- if ge $memtxMemoryBytes $memoryLimit -}}
                         {{- fail (printf
                            "tarantool.roles.%s.memtxMemory (current: %s) must be lover than tarantool.roles.%s.resources.limits.memory (current: %s)"
                            $role.name
                            $role.memtxMemory
                            $role.name
                            $resources.limits.memory
                        ) -}}
                    {{- end -}}
                {{- end -}}
            {{- end -}}
        {{- end -}}
    {{- else -}}
        {{- fail (printf "%s.memtxMemory doesn't set" $role.name) -}}
    {{- end -}}
{{- end }}

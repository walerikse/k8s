{{- define "tarantool.environment.sidecar" }}
  - name: CARTRIDGE_RUN_DIR
    value: {{ .Values.tarantool.runDir | quote }}
  - name: SIDECAR_PORT
    value: {{ .Values.sidecar.ports.http | quote }}
{{- end }}

{{- define "tarantool.environment.app" }}
  {{- $ := .context -}}
  {{- $role := .role -}}
  {{- $clusterName := (include "chart.fullname" $) -}}
  {{- $httpPort := (include "role.ports.http" (dict "role" $role "context" $)) -}}
  {{- $tarantoolPort := (include "role.ports.tarantool" (dict "role" $role "context" $)) -}}
  {{- $memtxMemory := ($role.memtxMemory | default $.Values.tarantool.memtxMemory) -}}
  {{- $memtxMemoryBytes := (include "tarantool.memory_quantity_to_bytes" $memtxMemory) | int64 -}}
  {{- $probeUriTimeout := ($role.probeUriTimeout | default $.Values.tarantool.probeUriTimeout) }}
  - name: TARANTOOL_INSTANCE_NAME
    valueFrom:
      fieldRef:
        fieldPath: metadata.name
  - name: TARANTOOL_HTTP_PORT
    value: {{ $httpPort | quote }}
  - name: TARANTOOL_MEMTX_MEMORY
    value: {{ $memtxMemoryBytes | quote }}
  - name: TARANTOOL_PROBE_URI_TIMEOUT
    value: {{ $probeUriTimeout | quote }}
  - name: TARANTOOL_BUCKET_COUNT
    value: {{ $.Values.tarantool.bucketCount | quote }}
  - name: TARANTOOL_WORKDIR
    value: {{ $.Values.tarantool.workDir | quote }}
  - name: TARANTOOL_USER
    value: {{ $.Values.tarantool.auth.user | default "admin" | quote }}
  - name: TARANTOOL_ALIAS
    value: "$(TARANTOOL_INSTANCE_NAME)"
  - name: TARANTOOL_ADVERTISE_HOST
    value: "$(TARANTOOL_INSTANCE_NAME).{{ $clusterName }}.{{ $.Release.Namespace }}.svc.{{ $.Values.clusterDomain }}"
  - name: TARANTOOL_ADVERTISE_URI
    value: "$(TARANTOOL_ADVERTISE_HOST):{{ $tarantoolPort }}"
  - name: TARANTOOL_CONNECTION_STRING
    value: "$(TARANTOOL_ADVERTISE_HOST):{{ $tarantoolPort }}"
  - name: CARTRIDGE_RUN_DIR
    value: {{ $.Values.tarantool.runDir | quote }}
{{- end }}

{{- define "tarantool.environment.ssl" }}
  - name: TARANTOOL_TRANSPORT
    value: "ssl"
  - name: TARANTOOL_SSL_SERVER_CA_FILE
    value: "{{ $.Values.tarantool.ssl.caDir }}/ca.crt"
  - name: TARANTOOL_SSL_SERVER_CERT_FILE
    value: "{{ $.Values.tarantool.ssl.serverDir }}/tls.crt"
  - name: TARANTOOL_SSL_SERVER_KEY_FILE
    value: "{{ $.Values.tarantool.ssl.serverDir }}/tls.key"
  - name: TARANTOOL_SSL_CLIENT_CA_FILE
    value: "{{ $.Values.tarantool.ssl.caDir | default "/certs/ca" }}/ca.crt"
  - name: TARANTOOL_SSL_CLIENT_CERT_FILE
    value: "{{ $.Values.tarantool.ssl.clientDir }}/tls.crt"
  - name: TARANTOOL_SSL_CLIENT_KEY_FILE
    value: "{{ $.Values.tarantool.ssl.clientDir }}/tls.key"
  {{- if $.Values.tarantool.ssl.ciphers }}
  - name: TARANTOOL_SSL_CIPHERS
    value: "{{ $.Values.tarantool.ssl.ciphers }}"
{{- end }}
{{- end }}

{{- define "tarantool.environment.extra" }}
  {{- $context := .context }}
  {{- $exist := dict }}
  {{- range $_, $list := .extra }}
    {{- range $list }}
      {{- if not (get $exist .name) }}
- {{ tpl (. | toYaml) $context | indent 2 | trim }}
      {{- end -}}
      {{- $_ := set $exist .name true -}}
    {{- end -}}
  {{- end -}}
{{- end }}

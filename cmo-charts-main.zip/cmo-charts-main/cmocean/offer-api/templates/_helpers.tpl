{{/*
Fully qualified app name is truncated at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "offer.postgresql.fullname" -}}
{{- include "common.names.dependency.fullname" (dict "chartName" "postgresql" "chartValues" .Values.postgresql "context" $) -}}
{{- end -}}

{{/*
Primary database host
*/}}
{{- define "offer.database.primary.host" -}}
{{- if eq .Values.postgresql.architecture "replication" -}}
{{- ternary (include "offer.postgresql.fullname" .) .Values.externalDatabase.primary.host .Values.postgresql.enabled -}}-primary
{{- else -}}
{{- ternary (include "offer.postgresql.fullname" .) .Values.externalDatabase.primary.host .Values.postgresql.enabled -}}
{{- end -}}
{{- end -}}

{{/*
Primary database port
*/}}
{{- define "offer.database.primary.port" -}}
{{- ternary "5432" .Values.externalDatabase.primary.port .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Replica database host
*/}}
{{- define "offer.database.replica.host" -}}
{{- if eq .Values.postgresql.architecture "replication" -}}
{{- ternary (include "offer.postgresql.fullname" .) .Values.externalDatabase.replica.host .Values.postgresql.enabled -}}-read
{{- else -}}
{{- ternary (include "offer.postgresql.fullname" .) .Values.externalDatabase.replica.host .Values.postgresql.enabled -}}
{{- end -}}
{{- end -}}

{{/*
Replica database port
*/}}
{{- define "offer.database.replica.port" -}}
{{- ternary "5432" .Values.externalDatabase.replica.port .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database name
*/}}
{{- define "offer.database.name" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- coalesce .Values.postgresql.global.postgresql.auth.database .Values.postgresql.auth.database -}}
        {{- else -}}
            {{- .Values.postgresql.auth.database -}}
        {{- end -}}
    {{- else -}}
        {{- .Values.postgresql.auth.database -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.database -}}
{{- end -}}
{{- end -}}

{{/*
Database schema
*/}}
{{- define "offer.database.schema" -}}
{{- ternary "public" .Values.externalDatabase.schema .Values.postgresql.enabled -}}
{{- end -}}

{{/*
Database user
*/}}
{{- define "offer.database.user" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- default (printf "%s" "postgres") (coalesce .Values.postgresql.global.postgresql.auth.username .Values.postgresql.auth.username) -}}
        {{- else -}}
            {{- default (printf "%s" "postgres") (tpl .Values.postgresql.auth.username) -}}
        {{- end -}}
    {{- else -}}
        {{- default (printf "%s" "postgres") (tpl .Values.postgresql.auth.username) -}}
    {{- end -}}
{{- else -}}
    {{- .Values.externalDatabase.user -}}
{{- end -}}
{{- end -}}

{{/*
Database password secret name
*/}}
{{- define "offer.database.secretName" -}}
{{- if .Values.postgresql.enabled -}}
    {{- if .Values.postgresql.global.postgresql -}}
        {{- if .Values.postgresql.global.postgresql.auth -}}
            {{- if .Values.postgresql.global.postgresql.auth.existingSecret -}}
                {{- tpl .Values.postgresql.global.postgresql.auth.existingSecret $ -}}
            {{- else -}}
                {{- default (include "offer.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
            {{- end -}}
        {{- else -}}
            {{- default (include "offer.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
        {{- end -}}
    {{- else -}}
        {{- default (include "offer.postgresql.fullname" .) (tpl .Values.postgresql.auth.existingSecret $) -}}
    {{- end -}}
{{- else -}}
    {{- default (printf "%s-externaldb" .Release.Name) (tpl .Values.externalDatabase.existingSecret $) -}}
{{- end -}}
{{- end -}}

{{/*
Database password secret key
*/}}
{{- define "offer.database.secretKey" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Database password existing secret key
*/}}
{{- define "offer.database.existingsecret.key" -}}
{{- if .Values.postgresql.enabled -}}
    {{- printf "%s" "password" -}}
{{- else -}}
    {{- if .Values.externalDatabase.existingSecret -}}
        {{- if .Values.externalDatabase.existingSecretPasswordKey -}}
            {{- printf "%s" .Values.externalDatabase.existingSecretPasswordKey -}}
        {{- else -}}
            {{- printf "%s" "password" -}}
        {{- end -}}
    {{- else -}}
        {{- printf "%s" "password" -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/* Validate values of Offer - database */}}
{{- define "offer.validateValues.database" -}}
{{- if and (not .Values.postgresql.enabled) (not .Values.externalDatabase.host) (and (not .Values.externalDatabase.password) (not .Values.externalDatabase.existingSecret)) -}}
offer: database
    You disabled the PostgreSQL sub-chart but did not specify an external PostgreSQL host.
    Either deploy the PostgreSQL sub-chart (--set postgresql.enabled=true),
    or set a value for the external database host (--set externalDatabase.host=FOO)
    and set a value for the external database password (--set externalDatabase.password=BAR)
    or existing secret (--set externalDatabase.existingSecret=BAR).
{{- end -}}
{{- end -}}


{{/* Kafka security protocol */}}
{{- define "offer.kafka.security.protocol" -}}
{{- if and (.Values.offerapi.kafka.sasl.enabled) (.Values.offerapi.kafka.ssl.enabled) -}}
    {{- printf "%s" "SASL_SSL" -}}
{{- else -}}
    {{- if .Values.offerapi.kafka.sasl.enabled -}}
        {{- printf "%s" "SASL_PLAINTEXT" -}}
    {{- else -}}
        {{- if .Values.offerapi.kafka.ssl.enabled -}}
            {{- printf "%s" "SSL" -}}
        {{- end -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/* Environment */}}
{{- define "offer.env" -}}
{{- .Values.service.env -}}
{{- end -}}
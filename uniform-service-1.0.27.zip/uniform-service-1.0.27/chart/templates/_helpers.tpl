{{/*
envFrom
*/}}
{{- define "helpers.envFrom" -}}
{{- range .vars }}
  {{- if and (eq .name nil) (eq .key nil) }}
    {{- if .secret }}
    - secretRef:
        name: {{ include "common.tplvalues.render" (dict "value" .secret "context" $.context) | quote }}
    {{- else if .configmap }}
    - configMapRef:
        name: {{ include "common.tplvalues.render" (dict "value" .configmap "context" $.context) | quote }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
env
*/}}
{{- define "helpers.env" -}}
{{- range .vars }}
  {{- if .name }}
    - name: {{ include "common.tplvalues.render" (dict "value" .name "context" $.context) | quote }}
      {{- if and .secret (ne .key nil) }}
      valueFrom:
        secretKeyRef:
          name: {{ include "common.tplvalues.render" (dict "value" .secret "context" $.context) | quote }}
          key: {{ include "common.tplvalues.render" (dict "value" .key "context" $.context) | quote }}
      {{- else if and .configmap (ne .key nil) }}
      valueFrom:
        configMapKeyRef:
          name: {{ include "common.tplvalues.render" (dict "value" .configmap "context" $.context) | quote }}
          key: {{ include "common.tplvalues.render" (dict "value" .key "context" $.context) | quote }}
      {{- else if .field }}
      valueFrom:
        fieldRef:
          fieldPath: {{ include "common.tplvalues.render" (dict "value" .field "context" $.context) | quote }}
          apiVersion: {{ .apiVersion | quote }}
      {{- else if .value }}
      value: {{ include "common.tplvalues.render" (dict "value" .value "context" $.context) | quote }}
      {{- else if .valueFrom }}
      valueFrom: {{ include "common.tplvalues.render" (dict "value" .valueFrom "context" $.context) | nindent 8 }}
      {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{- define "helpers.ingress.hosts" -}}
{{- $ingressHost := include "common.tplvalues.render" ( dict "value" .host "context" .context) -}}
{{ include "common.tplvalues.render" ( dict "value" $ingressHost "context" .context) }}.{{ include "common.tplvalues.render" ( dict "value" .baseDomain "context" .context) }}
{{- end }}

{{- define "helpers.gatewayApi.httpRoute.hostname" -}}
{{- $httpRouteHost := include "common.tplvalues.render" (dict "value" .host "context" .context) -}}
{{ include "common.tplvalues.render" (dict "value" $httpRouteHost "context" .context) }}.{{ include "common.tplvalues.render" (dict "value" .baseDomain "context" .context) }}
{{- end }}